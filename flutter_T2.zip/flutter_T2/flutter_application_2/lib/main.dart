import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: CalculatorScreen(),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _output = '0';
  String _currentNumber = '';
  double _num1 = 0;
  double _num2 = 0;
  String _operation = '';

  void _buttonPressed(String buttonText) {
    if (buttonText == 'C') {
      _output = '0';
      _currentNumber = '';
      _num1 = 0;
      _num2 = 0;
      _operation = '';
    } else if (buttonText == '+' ||
        buttonText == '-' ||
        buttonText == '×' ||
        buttonText == '÷') {
      _num1 = double.parse(_currentNumber);
      _operation = buttonText;
      _currentNumber = '';
    } else if (buttonText == '=') {
      _num2 = double.parse(_currentNumber);
      if (_operation == '+') {
        _output = (_num1 + _num2).toString();
      } else if (_operation == '-') {
        _output = (_num1 - _num2).toString();
      } else if (_operation == '×') {
        _output = (_num1 * _num2).toString();
      } else if (_operation == '÷') {
        _output = (_num1 / _num2).toString();
      }
      _operation = '';
      _num1 = 0;
      _num2 = 0;
      _currentNumber = '';
    } else if (buttonText == '.') {
      if (!(_currentNumber.contains('.'))) {
        _currentNumber += '.';
      }
    } else if (buttonText == '1/x') {
      _num1 = double.parse(_currentNumber);
      if (_num1 != 0) {
        _output = (1 / _num1).toString();
      } else {
        _output = "Error";
      }
    } else if (buttonText == 'X^2') {
      _num1 = double.parse(_currentNumber);
      _output = (_num1 * _num1).toString();
    } else if (buttonText == '%') {
      _num1 = double.parse(_currentNumber);
      _output = (_num1 / 100).toString();
    } else if (buttonText == 'Del') {
      if (_currentNumber.isNotEmpty) {
        _currentNumber = _currentNumber.substring(0, _currentNumber.length - 1);
      }
    } else if (buttonText == '+/-') {
      if (_currentNumber.startsWith('-')) {
        _currentNumber = _currentNumber.substring(1);
      } else {
        _currentNumber = '-$_currentNumber';
      }
    } else if (buttonText == '√') {
      _num1 = double.parse(_currentNumber);
      _output = sqrt(_num1).toString();
    } else if (buttonText == 'n!') {
      _num1 = double.parse(_currentNumber);
      int fact = 1;
      for (int i = 1; i <= _num1; i++) {
        fact *= i;
      }
      _output = fact.toString();
    } else {
      _currentNumber += buttonText;
      _output = _currentNumber;
    }
    setState(() {});
  }

  Widget _buildButton(String buttonText) {
    return Expanded(
      child: OutlinedButton(
        onPressed: () => _buttonPressed(buttonText),
        child: Text(
          buttonText,
          style: TextStyle(fontSize: 20.0),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculator'),
      ),
      body: Container(
        child: Column(
          children: <Widget>[
            Container(
              alignment: Alignment.centerRight,
              padding: EdgeInsets.symmetric(vertical: 24.0, horizontal: 12.0),
              child: Text(
                _output,
                style: TextStyle(fontSize: 48.0),
              ),
            ),
            Expanded(
              child: Divider(),
            ),
            Column(
              children: <Widget>[
                Row(
                  children: <Widget>[
                    _buildButton('7'),
                    _buildButton('8'),
                    _buildButton('9'),
                    _buildButton('÷'),
                  ],
                ),
                Row(
                  children: <Widget>[
                    _buildButton('4'),
                    _buildButton('5'),
                    _buildButton('6'),
                    _buildButton('×'),
                  ],
                ),
                Row(
                  children: <Widget>[
                    _buildButton('1'),
                    _buildButton('2'),
                    _buildButton('3'),
                    _buildButton('-'),
                  ],
                ),
                Row(
                  children: <Widget>[
                    _buildButton('C'),
                    _buildButton('0'),
                    _buildButton('='),
                    _buildButton('+'),
                  ],
                ),
                Row(
                  children: <Widget>[
                    _buildButton('+/-'),
                    _buildButton('.'),
                    _buildButton('Del'),
                    _buildButton('n!'),
                  ],
                ),
                Row(
                  children: <Widget>[
                    _buildButton('√'),
                    _buildButton('%'),
                    _buildButton('X^2'),
                    _buildButton('1/x'),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
