import 'package:flutter/material.dart';

Stream<int> LayDuLieu() async* {
  for (var i = 0; i < 10; i++) {
    await Future.delayed(Duration(seconds: 2));
    yield i;
  }
}

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  //giaodien
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: StreamBuilder<int>(
          stream: LayDuLieu(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return CircularProgressIndicator();
            } else if (snapshot.hasError) {
              return Text('loi: ${snapshot.error}');
            } else {
              return Text('Du lieu nguoi dung: ${snapshot.data}');
            }
          },
        ),
      ),
    );
  }
}
