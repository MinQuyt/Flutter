package com.example.ungdung_calc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
