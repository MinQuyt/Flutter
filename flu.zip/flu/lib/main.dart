import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import "package:http/http.dart" as http;
import 'dart:convert';
//tạo product 
class Product{
  String search_image;
  String styleid;
  String brands_filter_facet;
  String price;
  String product_additional_info;
  Product({
    required this.search_image,
    required this.styleid,
    required this.brands_filter_facet,
    required this.price,
    required this.product_additional_info
  });
}
//lop ket noi giao dien
class ProductListScreen extends StatefulWidget{
  @override
  _ProductListScreen createState() => _ProductListScreen();
}
class _ProductListScreen extends State<ProductListScreen>{
  //khai bao list du lieu
  late List<Product> products;
  //khoi tao trang thai 
  @override
  void initState(){
    super.initState();
  products = [];
  fetchProducts();
  }
  List<Product> convertMaptoList(Map<String, dynamic> data) {
    List<Product> productList = [];

    data.forEach((key, value) {
      for (int i = 0; i < value.length; i++) {
        Product product = Product(
          search_image: value[i]['search_image'] ?? '',
          styleid: value[i]['styleid'] ?? '',
          brands_filter_facet: value[i]['brands_filter_facet'] ?? '',
          price: value[i]['price'] ?? '',
          product_additional_info: value[i]['product_additional_info'] ?? '',
        );

        productList.add(product);
      }
    });

    return productList;
  }
  Future <void> fetchProducts() async {
    final response= await http.get(Uri.parse("http://192.168.1.107/aflutter/API.php"));
    if(response.statusCode ==200){
      final Map<String,dynamic> data=json.decode(response.body);
      setState(() {
        products=convertMaptoList(data);
      });
    }
    else{
      throw Exception("khong co du lieu");
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("danh sach san pham"),
      ),
      body: products !=null?
      ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index){
          return ListTile(
             title: Text(products[index].brands_filter_facet),
             subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Price ${products[index].price}'),
              ],
             ),
             leading: Image.network(
              products[index].search_image,
              width: 50,
              height: 50,
              fit: BoxFit.cover,

             ),
          );
        }
        ): Center(
          child: CircularProgressIndicator(),
        ),
    );
  }
}
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Danh sách sản phẩm",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSwatch(
          primarySwatch: Colors.deepPurple,
        ),
      ),
      home: HomeScreen(),
      //ProductListScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Home Screen"),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ProductListScreen()),
            );
          },
          child: Text("Go to List Screen"),
        ),
      ),
    );
  }
}

void main() {
  runApp(const MyApp());
}