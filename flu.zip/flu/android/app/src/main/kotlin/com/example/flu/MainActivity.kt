package com.example.flu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
